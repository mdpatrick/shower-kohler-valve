# Fresh FT01 review request

Read START_HERE.md, canon/fit_trial_design.json, canon/fit_trial_handoff.json, canon/project_state.json and docs/fabrication_goal_prompt.md. The immediate goal is a useful real quote/physical trial, not permanent-installation certification. The full original request remains in docs/project_request.md. Historical F005/CB01/AP01 shapes are not the next quote design.

Review deliverables/current/fabrication/fit-trial/index.html, design_report.json, attached_scan_assessment.json and audit.json. Separate claims you read, visually inspect, recompute or physically verify. The supplied fresh audit is a same-agent independent calculation, not a second reviewer.

Recompute all six STEP/STL/DXF sets: mm, centered profiles, two contours, main220 capsule116.35x151.10 endR58.175 /straight34.75, diverter124 or120 with80 aperture, thickness1.524 or3.000. Check clean DXF entities, analytic volume, watertight STL and same geometry in Blender. Verify shop notes, printable100mm bars, private-free quote ZIPs, hashes and current source dependencies. Run `./project prepare-fit-trial --stage audit`.

Challenge the claimed clearance scope: 51,929 primary-scan pieces aboveZ0.5 and inside OPEN-MAIN eroded3mm. It excludes stone-edge insertion and hidden geometry. About1.6mm minimum is not a field tolerance. Check the alternative capsule's foam land and corner sensitivity; only1mm nominal extra land is narrow and real foam footprint is unverified. Do not treat all three pose hypotheses as an error bound.

Inspect the newly attached scan directly without forcing concentricity. Its wall-normal view has stems high in hub rings, but reflective distortion and the width cross-check conflict with calipers. It is not globally registered to the original scan. Check the distinction between whole handle body and its rear connection, genuine factory engagement, added-depth loss, plate alignment and rod/wood adjustment. Six3D caliper readings do not define coplanar stud holes.

Check both custom parts together: concentric visible borders, damage coverage versus sound support, actual cover centers, narrow neighbor gap, diverter rear footprint atØ80 opening, clamping/support stiffness, retention without fixed tabs, all gasket contact, bottom drain, service removal and water path. Demand recorded physical results before permanent release. User conditionally allows wood relief; no tile modification.

Review costs as planning allowances, not quotes. Finished sheet metal may be a sacrificial first trial at≤2×plastic; no metal3Dprinting is required. Verify current vendor options before purchase. No upload/order/trade message is authorized by this review.

Preserve evidence and accepted canon. Record proposed corrections with source and consequence, then rerun dependent checks. The fuller historical audit checklist remains in docs/downstream_audit_prompt_pre_FT01.md.
