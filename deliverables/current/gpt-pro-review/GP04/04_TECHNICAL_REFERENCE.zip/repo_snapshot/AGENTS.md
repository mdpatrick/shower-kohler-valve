**Current recommendation: FT01 quote and physical fit trial.** Read START_HERE.md, canon/fit_trial_design.json, canon/fit_trial_handoff.json and deliverables/current/fabrication/fit-trial/audit.json first. Main Ø220 with upright capsule 116.35 × 151.10 R58.175; diverter Ø124/80 with Ø120 fallback; 1.524 mm metal/print and 3 mm plastic alternative. No fixed bolt tabs. Use `./project prepare-fit-trial` and preserve historical F005/CB01/AP01 files. Public vendor research is not a quote; do not block useful prototype pricing on unperformed permanent-installation checks.

**New attached scan is assessed, not globally registered.** Source ZIP remains intact. See deliverables/current/fabrication/fit-trial/attached_scan_assessment.json: wall-normal diagnostic, manual picks and uniform scale calibrated to 80 mm U–L, not independently validated. Visible stems sit high in hub rings; width differs about 4 mm from calipers. Do not force alignment, dismiss this as the old point-pick problem, or turn it into precise hole positions. Keep primary scan/transform unchanged and actual observed state separate from proposed appearance.

The current three-scene Blender file is deliverables/current/fabrication/fit-trial/escutcheon_fit_trial_FT01.blend. The capsule clears scoped captured surfaces in three historical placement scenarios; minimum about 1.6 mm is not a physical error allowance. The nominal extra foam land is only 1 mm. Factory engagement, footprint, support/retention, seal detail and water test remain open. Original AP01 R33 and diagonal CB01 shapes are historical, not files to send for this next trial.

# Shower installation reconstruction

Read START_HERE.md, canon/project_state.json and docs/project_request.md first.

Latest qualitative correction: read docs/physical_checks/foam_edge_and_access_2026-10-15.json and canon/aperture_access_study.json. Foam meets the removed inner plate's outer edge; rod/wood contact is user-confirmed. Conditional wood relief for trim-stud retraction is authorized if other valve/handle depths pass; tile restrictions remain. AP01 is a separate upright-aperture dry-fit candidate, not a manufacturing release. Rebuild with `./project prepare-aperture`; do not silently replace historic CB01 quote files or treat full opening footprints as measured adapter/hub diameters.

Preserve the travertine: no additional cutting, grinding, drilling, enlargement or retiling without an explicit user exception. Retain factory inner plate, gasket, drainage and service functions. No uploads, publishing, orders or messages to trades without authorization.

The wall-and-valve Polycam ZIP is the primary installed reference. The two plate-side scans are secondary and distorted; identify contents and local credible features before using them. Never average these into or straighten the installed wall/valve scan. Accepted physical observations outrank scan estimates. Manufacturer dimensions are nominal and conditional on identity. Keep all conflicting evidence.

Canon and CAD use mm: +X right, +Y up, +Z out from wall, viewed from shower. Transform into Blender meters with (x,-z,y)/1000 once. Preserve original coordinates and record transforms. Never claim physical scale based on unit labels. Keep observed, nominal, proposed and selected states separate.

CadQuery is the manufactured-geometry master. Blender is the inspection workspace; HTML is the measurement interface. Custom plate display meshes must come from the CAD solid. Existing Kohler solids are reference reconstructions only. Unknown critical values stay unknown; provisional visualization parameters are not accepted measurements or fabrication dimensions.

Use ./project commands; inspect --help. Do not overwrite canon with build scripts. Import measurements by project/revision/ID/units with history and conflict checks. Preserve manual/user annotations in a separate file or configuration. Latest user direction authorizes real quote and sacrificial dry-fit files: FT01 uses FIT_TRIAL filenames and FOR_QUOTE_AND_DRY_FIT_ONLY status. Permanent installation remains unreleased; keep older unvalidated studies DRAFT_NOT_FOR_FABRICATION. A geometric export check is not a physical fit, waterproofing or fabrication approval.

Ordinary Git only, no Git LFS. Preserve actual ZIP bytes, existing hooks, identity and history. No remotes/push without approval. Track raw ZIPs and selected deliverables; ignore extracts, caches and environments. Inspect stages before meaningful commits. Validate blobs, clean clone recovery and bundle restore. All normal processing uses repository-relative inputs, never Downloads. Local Git is not an off-machine backup.

Document executed tests separately from reviewed claims. An independent/fresh adversarial review is required before fabrication readiness. Do not use unobserved hidden construction or generated images as evidence. No physical checks may be marked complete without revisioned user/installer results.
