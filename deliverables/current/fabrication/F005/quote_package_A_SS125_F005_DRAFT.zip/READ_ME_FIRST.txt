F005 - DRAFT NOT FOR FABRICATION
QUOTE / PROTOTYPE REVIEW ONLY; permanent manufacture on hold.
Choose pair A; quantity 1 MAIN-A and 1 DIV-A.
Requested stock: 316 stainless steel; exact CAD thickness 3.175 mm.
DXF units millimeters, 1:1; two closed contours, no separate fastener holes.
Do not scale; do not make the other thickness variants shown in the reference drawing table.
XY +/-0.13 mm and flatness <=0.5 mm are requested quote targets, not demonstrated capabilities. Confirm actual sheet thickness tolerance and finishing changes.
Deburr all edges; remove tabs; protect satin cosmetic face. Grain direction +Y on both parts. Finish sample and support/seal fit require approval.
No scans, homeowner photos or Kohler replacement geometry are included.
No upload/order has been made. Contact/ordering requires separate user authorization.
