CB01 C1 SS125 - DRAFT, QUOTE / PROTOTYPE REVIEW ONLY.
One main plate and one diverter plate. 316 stainless steel; nominal thickness 3.175 mm.
No manufacture/order authorization. STEP/DXF units mm. STL numerics are mm, a unitless format.
Only the two custom parts are supplied; no Kohler replacement part or home scan.
Local XY origin is each outer circle center, rear Z=0. DXF has exactly two closed contours.
Stock dimensions, flatness, edge quality, finish and position tolerances require shop confirmation.
Support, rear foam landing, stud/cover/handle fit, centering and water sealing remain unresolved.
Clear acrylic / printed plastic trials are for dry fit only, not permanent wet service.
