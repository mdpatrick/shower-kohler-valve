FT01 - QUOTE AND SACRIFICIAL FIT TRIAL ONLY
Quantity: one MAIN220 plus one DIV124. All coordinates mm. No assembly scaling.
Thickness: 1.524 mm. STEP solid is authoritative; DXF is a thickness-free mm cutting profile. STL coordinates are mm.
Metal T1524: quote 316 stainless, deburred and grain finished; compare 304 brushed if useful.
Plastic T3000: 3mm clear acrylic or solid PETG/PLA; dry fit only. T1524 STL may also be printed for a thickness-matched trial.
Confirm profile tolerance, flatness, actual thickness, finish, edges and delivery. No silent substitution.
Remove cutting tabs (not mounting tabs), burrs and sharp edges. Uniform protected cosmetic face.
No integral mounting tabs, threads, bends or countersinks. No kerf compensation in file.
No permanent-installation release: actual factory fit, support, seal and water performance require on-site review.
